<?php

class Trash extends DataMapper {
	
	var $table = 'trash';
}

/* End of file trash.php */
/* Location: ./application/models/trash.php */