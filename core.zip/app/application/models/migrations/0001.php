<?php

	// DUMMY
	sleep(1);
	$done = true;